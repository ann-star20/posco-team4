from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from operator_report.render import build_report, write_bundle
from operator_report.rules import evaluate


class RuleTests(unittest.TestCase):
    def test_fail_produces_advisory_actions(self) -> None:
        rows = evaluate([{"kind": "aoi", "status": "fail", "target_type": "lot", "target_id": "L1", "evidence_id": "E1"}])
        self.assertEqual({row["action_code"] for row in rows}, {"reinspect_item", "review_quality_hold"})
        self.assertTrue(all(row["operator_decision_required"] for row in rows))

    def test_repeated_valid_ood_requests_coverage_review(self) -> None:
        rows = evaluate([{"kind": "surrogate", "status": "out_of_domain", "ood_class": "coverage_gap_candidate", "repeat_count": 3, "repeat_threshold": 3, "target_id": "x", "evidence_id": "E2"}])
        self.assertEqual(rows[0]["action_code"], "review_training_coverage")

    def test_no_signal_is_monitor_only(self) -> None:
        self.assertEqual(evaluate([])[0]["action_code"], "monitor_only")


class RenderTests(unittest.TestCase):
    def test_bundle_contains_all_required_files(self) -> None:
        snapshot = {"snapshot_id": "s1", "period": {"start": "a", "end": "b"}, "summary": {}, "data_quality": {}}
        report = build_report(snapshot, evaluate([]))
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory)
            write_bundle(report, [], output, {"mode": "test"})
            self.assertEqual(
                {path.name for path in output.iterdir()},
                {"report.json", "report.md", "report.html", "evidence.jsonl", "generation.json"},
            )
            self.assertTrue(json.loads((output / "report.json").read_text(encoding="utf-8"))["advisory_only"])


if __name__ == "__main__":
    unittest.main()

